#include <stdio.h>

#define MAX_CHARA 80

int main()
{
    int longueur = 0;
    int cmptr = 0;
    char tableau[MAX_CHARA];

    for(int i = 0; i < MAX_CHARA; i++)
    {
        scanf("%c", &tableau[i]);

        if (tableau[i] == '\n')
        {
            break;
        }

        cmptr++;
    }

    for (int i = 0; i < MAX_CHARA; i++)
    {
        printf("%c", tableau[i]);
    }

    printf("\n");

    printf("Chaine de caractère(s) inversée : ");

    for (int i = MAX_CHARA; i >= 0; i--)
    {
        printf("%c", tableau[i]);
    }

    printf("\n");

    for (int i = 0; i < MAX_CHARA; i++)
    {
        if (tableau[i] != tableau[cmptr-i])
        {
            printf("Pas palindrome.");
            return 0;
        }
    }

    printf("Palindrome.");

    return 0;
}
