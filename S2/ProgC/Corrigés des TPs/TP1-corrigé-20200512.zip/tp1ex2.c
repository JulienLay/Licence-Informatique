#include <stdio.h>

int main(void)
{
  printf("Mon premier programme !\n");

  return 0;
}

