#include <stdio.h>

int main(void)
{
  int n;

  printf("Tapez un entier : ");
  scanf("%d",&n);
  printf("Le carre de %d est %d.\n",n,n*n);

  return 0;
}

