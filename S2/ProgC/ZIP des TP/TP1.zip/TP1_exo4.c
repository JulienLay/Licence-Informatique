#include<stdio.h>
#include<math.h>

int main(void) {
  double nbr;
  scanf("%lf",&nbr);
  nbr = sqrt(nbr);
  printf("%lf\n",nbr);
  return 0;
}