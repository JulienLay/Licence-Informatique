#include<stdio.h>

int main(void) {
  int nbr;
  scanf("%d",&nbr);
  nbr *= nbr;
  printf("%d\n",nbr);
  return 0;
}